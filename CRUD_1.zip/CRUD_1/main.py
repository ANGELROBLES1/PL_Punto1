from antlr4 import *
from ANTLexer import ANTLexer
from ANTParser import ANTParser

def evaluar_linea(linea, num):
    input_stream = InputStream(linea)
    lexer = ANTLexer(input_stream)
    stream = CommonTokenStream(lexer)
    parser = ANTParser(stream)

    try:
        parser.start()
        print(f"Linea {num}: VALIDA")
    except:
        print(f"Linea {num}: ERROR")

def evaluar_archivo(nombre_archivo):
    with open(nombre_archivo, 'r') as f:
        lineas = f.readlines()

    for i, linea in enumerate(lineas, start=1):
        if linea.strip():  # evitar líneas vacías
            evaluar_linea(linea.strip(), i)

if __name__ == "__main__":
    evaluar_archivo("ejemplos.txt")
