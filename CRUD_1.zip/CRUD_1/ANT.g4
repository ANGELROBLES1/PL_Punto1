grammar ANT;

start : stmt+ EOF ;

stmt
    : pushStmt
    | pullStmt
    | shiftStmt
    | dropStmt
    ;

pushStmt : 'PUSH' ID 'WITH' struct ;
pullStmt : 'PULL' ID 'FILTER' cond ;
shiftStmt: 'SHIFT' ID 'REPLACE' struct 'FILTER' cond ;
dropStmt : 'DROP' ID 'FILTER' cond ;

struct : '[' pair (',' pair)* ']' ;

pair : ID '=>' value ;

cond : ID operator value ;

operator : '==' | '!=' | '>' | '<' ;

value : STRING | NUMBER ;

ID : [a-zA-Z_][a-zA-Z0-9_]* ;
NUMBER : [0-9]+ ;
STRING : '"' .*? '"' ;

WS : [ \t\r\n]+ -> skip ;
